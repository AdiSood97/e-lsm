import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { AuthenticationService } from '../../../_services/authentication.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  constructor(
    public authService: AuthenticationService,
    public router: Router,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private modalService: NgbModal
  ) {}

  loginForm: FormGroup;
  forgotForm: FormGroup;
  submitted = false;
  submitted1 = false;
  modalRef;

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: [
        '',
        [
          Validators.required,
          Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$'),
        ],
      ],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });

    this.forgotForm = this.formBuilder.group({
      email: [
        '',
        [
          Validators.required,
          Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$'),
        ],
      ],
    });
  }

  get f() {
    return this.loginForm.controls;
  }

  get d() {
    return this.forgotForm.controls;
  }

  onLogIn() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }
    this.authService
      .login(this.loginForm.value.email, this.loginForm.value.password)
      .subscribe(
        (res) => {
          console.log(res);
          this.toastr.success('Logged in successfully', 'Success!');
          this.router.navigate(['app/dashboard']);
        },
        (error) => {
          console.error(error);
          this.toastr.error(error, 'Error');
        }
      );
  }

  open(content) {
    this.modalRef = this.modalService.open(content, {
      size: 'md',
      backdrop: 'static',
    });
  }

  forgotPassword() {
    this.submitted1 = true;
    if (this.forgotForm.invalid) {
      return;
    }
    this.authService
      .sendPasswordResetEmail(this.forgotForm.value.email)
      .subscribe(
        (res) => {
          this.modalRef.close()
          this.forgotForm.reset();

          this.toastr.success('Request Sent successfully', 'Success!');
        },
        (error) => {
          console.error(error);
          this.toastr.error(error, 'Error');
        }
      );
  }
}
