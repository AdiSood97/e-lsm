const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');
const { status } = require('../config/status');

const answerSchema = mongoose.Schema(
  {
    survey: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'Survey',
    },
    student: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'User',
    },
    question: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'Questiion',
    },
    answer: {
      type: String,
      required: true,
    },
    mark: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      enum: status,
      default: 'pending',
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
answerSchema.plugin(toJSON);
answerSchema.plugin(paginate);

/**
 * @typedef Answer
 */
const Answer = mongoose.model('Answer', answerSchema);

module.exports = Answer;
