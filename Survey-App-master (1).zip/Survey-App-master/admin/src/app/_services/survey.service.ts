import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable()
export class SurveyService {
    public readonly apiUrl = environment.API_BASE_URL;

    constructor(public http: HttpClient, public sanitizer: DomSanitizer) {
        // set token if saved in local storage
    }

    // Get all survey list
    getSurveys() {
        return this.http
            .get(`${this.apiUrl}surveys?sortBy=name&limit=10&page=1`)
            .pipe(
                map((response: Response) => {
                    return response;
                })
            );
    }

    // Get survey by id
    getSurveyById(surveyId: String) {
        return this.http
            .get(`${this.apiUrl}surveys/${surveyId}`)
            .pipe(
                map((response: Response) => {
                    return response;
                })
            );
    }

    // Add New Survey
    addSurvey(school: String, teacher: String, student: String) {
        return this.http
            .post(`${this.apiUrl}surveys`, {
                school: school,
                teacher: teacher,
                student: student,
            })
            .pipe(
                map((response: Response) => {
                    return response;
                })
            );
    }

    // Delete Survey
    deleteSurvey(surveyId: String) {
        return this.http
            .delete(`${this.apiUrl}surveys/${surveyId}`)
            .pipe(
                map((response: Response) => {
                    return response;
                })
            );
    }
}
