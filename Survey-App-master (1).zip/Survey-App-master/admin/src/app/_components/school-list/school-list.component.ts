import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SchoolService } from '../../_services/index';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-school-list',
  templateUrl: './school-list.component.html',
  styleUrls: ['./school-list.component.css'],
})
export class SchoolListComponent implements OnInit {
  public tableData1: any = [];

  constructor(
    private schoolService: SchoolService,
    public router: Router,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private modalService: NgbModal
  ) {}

  schoolForm: FormGroup;
  submitted = false;
  modalRef;

  ngOnInit() {
    this.schoolForm = this.formBuilder.group({
      name: ['', [Validators.required]],
      address: ['', [Validators.required]],
    });
    this.getSchools();
  }

  get f() {
    return this.schoolForm.controls;
  }

  getSchools() {
    this.schoolService.getSchools().subscribe(
      (res) => {
        console.log(res);
        this.tableData1 = res;
      },
      (error) => {
        console.error(error);
        this.toastr.error(error, 'Error');
      }
    );
  }

  open(content) {
    this.modalRef = this.modalService.open(content, {
      size: 'lg',
      backdrop: 'static',
    });
  }

  addSchool() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.schoolForm.invalid) {
      return;
    }
    this.schoolService
      .addSchool(this.schoolForm.value.name, this.schoolForm.value.address)
      .subscribe(
        (res) => {
          console.log(res);
          this.toastr.success('School Added successfully', 'Success!');
          this.schoolForm.reset();
          this.getSchools();
        },
        (error) => {
          console.error(error);
          this.toastr.error(error, 'Error');
        }
      );
  }

  deleteSchool(schoolId) {
    this.schoolService.deleteSchool(schoolId).subscribe(
      (res) => {
        this.toastr.success('School Deleted successfully', 'Success!');
        this.getSchools();
      },
      (error) => {
        this.toastr.error(error, 'Error');
      }
    );
  }
}
