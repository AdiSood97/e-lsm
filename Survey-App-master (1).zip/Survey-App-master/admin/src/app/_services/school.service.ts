import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable()
export class SchoolService {
  public readonly apiUrl = environment.API_BASE_URL;

  constructor(public http: HttpClient, public sanitizer: DomSanitizer) {
    // set token if saved in local storage
  }

  // Get all school list
  getSchools() {
    return this.http
      .get(`${this.apiUrl}schools?sortBy=name&limit=10&page=1&name=`)
      .pipe(
        map((response: Response) => {
          return response;
        })
      );
  }

  // Add New school
  addSchool(name: String, address: String) {
    return this.http
      .post(`${this.apiUrl}schools`, {
        name: name,
        address: address,
      })
      .pipe(
        map((response: Response) => {
          return response;
        })
      );
  }

  // Delete school
  deleteSchool(schoolId: String) {
    return this.http
      .delete(`${this.apiUrl}schools/${schoolId}`)
      .pipe(
        map((response: Response) => {
          return response;
        })
      );
  }
}
