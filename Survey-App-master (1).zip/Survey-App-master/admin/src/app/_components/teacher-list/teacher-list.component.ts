import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../_services/index';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-teacher-list',
  templateUrl: './teacher-list.component.html',
  styleUrls: ['./teacher-list.component.css'],
})
export class TeacherListComponent implements OnInit {
  public tableData1: any = [];
  public modalRef;
  public schoolList: any = [];
  constructor(
    private userService: UserService,
    public router: Router,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private modalService: NgbModal
  ) {}

  teacherForm: FormGroup;
  submitted = false;

  ngOnInit() {
    this.teacherForm = this.formBuilder.group({
      name: ['', [Validators.required]],
      school: ['', [Validators.required]],
      email: [
        '',
        [
          Validators.required,
          Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$'),
        ],
      ],
    });
    this.getAllSchools();
    this.getTeachers();
  }

  get f() {
    return this.teacherForm.controls;
  }

  getTeachers() {
    this.userService.getUsers('teacher').subscribe(
      (res) => {
        console.log(res);
        this.tableData1 = res;
      },
      (error) => {
        console.error(error);
        this.toastr.error(error, 'Error');
      }
    );
  }

  getAllSchools() {
    this.userService.getAllSchools().subscribe(
      (res) => {
        console.log(res);
        this.schoolList = res['results'];
      },
      (error) => {
        console.error(error);
        this.toastr.error(error, 'Error');
      }
    );
  }

  open(content) {
    this.modalRef = this.modalService.open(content, {
      size: 'lg',
      backdrop: 'static',
    });
  }

  addTeacher() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.teacherForm.invalid) {
      return;
    }
    this.userService
      .addTeacher(
        this.teacherForm.value.name,
        this.teacherForm.value.email,
        'Admin@123',
        'teacher',
        this.teacherForm.value.school
      )
      .subscribe(
        (res) => {
          console.log(res);
          this.toastr.success('Teacher Added successfully', 'Success!');
          this.teacherForm.reset();
          this.getTeachers();
        },
        (error) => {
          console.error(error);
          this.toastr.error(error, 'Error');
        }
      );
  }

  deleteTeacher(teacherId) {
    this.userService.deleteUser(teacherId).subscribe(
      (res) => {
        this.toastr.success('Teacher Deleted successfully', 'Success!');
        this.getTeachers();
      },
      (error) => {
        this.toastr.error(error, 'Error');
      }
    );
  }
}
