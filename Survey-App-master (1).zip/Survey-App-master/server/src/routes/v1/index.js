const express = require('express');
const authRoute = require('./auth.route');
const userRoute = require('./user.route');
const docsRoute = require('./docs.route');
const schoolsRoute = require('./school.route');
const surveysRoute = require('./survey.route');

const router = express.Router();

router.use('/auth', authRoute);
router.use('/users', userRoute);
router.use('/docs', docsRoute);
router.use('/schools', schoolsRoute);
router.use('/surveys', surveysRoute);

module.exports = router;
