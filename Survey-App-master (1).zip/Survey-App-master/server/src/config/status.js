const status = ['pending', 'done'];

module.exports = {
  status,
};
