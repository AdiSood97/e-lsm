import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthenticationService } from '../../../_services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MustMatch } from '../../../_helpers/mustMatch.validator';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css'],
})
export class ResetPasswordComponent implements OnInit {
  constructor(
    public authService: AuthenticationService,
    public router: Router,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private route: ActivatedRoute
  ) {}

  resetForm: FormGroup;
  submitted = false;
  token: string = ''

  ngOnInit() {
    this.token = this.route.snapshot.queryParamMap.get('token');
    this.resetForm = this.formBuilder.group(
      {
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirm_password: ['', [Validators.required, Validators.minLength(6)]],
      },
      {
        validator: [MustMatch('password', 'confirm_password')],
      }
    );
  }

  get f() {
    return this.resetForm.controls;
  }

  resetPassword() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.resetForm.invalid) {
      return;
    }
    this.authService.resetPassword(this.resetForm.value.password, this.token).subscribe(
      (res) => {
        console.log(res);
        this.toastr.success('Your Password has been reset successfully', 'Success!');
        this.router.navigate(['auth/login']);
      },
      (error) => {
        console.error(error);
        this.toastr.error(error, 'Error');
      }
    );
  }
}
