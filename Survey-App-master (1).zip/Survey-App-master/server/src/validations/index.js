module.exports.authValidation = require('./auth.validation');
module.exports.userValidation = require('./user.validation');
module.exports.schoolValidation = require('./school.validation');
module.exports.surveyValidation = require('./survey.validation');
