export interface Dummy {
  unique_column: number;
  column_1: string;
  column_2: string;
  column_3: string;
}
