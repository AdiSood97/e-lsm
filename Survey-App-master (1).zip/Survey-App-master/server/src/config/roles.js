const roles = ['user', 'teacher', 'admin'];

const roleRights = new Map();
roleRights.set(roles[0], ['getSurvey']);
roleRights.set(roles[1], [
  'getUsers',
  'manageUsers',
  'getSchools',
  'manageSchools',
  'getSurvey',
  'getSurveys',
  'manageSurveys',
]);
roleRights.set(roles[2], [
  'getUsers',
  'manageUsers',
  'getSchools',
  'manageSchools',
  'getSurvey',
  'getSurveys',
  'manageSurveys',
]);

module.exports = {
  roles,
  roleRights,
};
