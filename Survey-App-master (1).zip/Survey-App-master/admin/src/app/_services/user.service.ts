import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable()
export class UserService {
  public readonly apiUrl = environment.API_BASE_URL;

  constructor(public http: HttpClient, public sanitizer: DomSanitizer) {
    // set token if saved in local storage
  }

  // Get all user list role wise
  getUsers(role: String) {
    return this.http
      .get(`${this.apiUrl}users/all?role=${role}`)
      .pipe(
        map((response: Response) => {
          return response;
        })
      );
  }

  // Get user by id
  getUserById(userId: String) {
    return this.http
      .get(`${this.apiUrl}users/${userId}`)
      .pipe(
        map((response: Response) => {
          return response;
        })
      );
  }

  // Get all schools list
  getAllSchools() {
    return this.http
      .get(`${this.apiUrl}schools?sortBy=name&limit=10000&page=1&name=`)
      .pipe(
        map((response: Response) => {
          return response;
        })
      );
  }

  // Add New Teacher
  addTeacher(
    name: String,
    email: String,
    password: String,
    role: String,
    school: any
  ) {
    return this.http
      .post(`${this.apiUrl}users`, {
        name: name,
        email: email,
        password: password,
        role: role,
        school: school,
      })
      .pipe(
        map((response: Response) => {
          return response;
        })
      );
  }

  // Add New Student
  addStudent(
    name: String,
    email: String,
    password: String,
    role: String,
    school: String,
    teacher: String,
    age: Number,
    gender: String
  ) {
    return this.http
      .post(`${this.apiUrl}users`, {
        name: name,
        email: email,
        password: password,
        role: role,
        school: school,
        teacher: teacher,
        age: age,
        gender: gender,
      })
      .pipe(
        map((response: Response) => {
          return response;
        })
      );
  }

  // Delete User
  deleteUser(userId: String) {
    return this.http.delete(`${this.apiUrl}users/${userId}`).pipe(
      map((response: Response) => {
        return response;
      })
    );
  }
}
