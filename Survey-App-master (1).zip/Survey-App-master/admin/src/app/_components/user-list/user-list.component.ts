import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService, SurveyService} from '../../_services/index';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css'],
})
export class UserListComponent implements OnInit {
  public tableData1: any = [];
  public modalRef;
  public schoolList: any = [];
  constructor(
    private userService: UserService,
    public router: Router,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private modalService: NgbModal,
    private surveyService: SurveyService
  ) {}


  str = "Java Script Object Notation";



  studentForm: FormGroup;
  submitted = false;
  userData: any = [];
  matches: any;
  acronym: any;

  ngOnInit() {

    
    this.userData = JSON.parse(localStorage.getItem('user'));
    this.matches = this.userData.name.match(/\b(\w)/g); // ['J','S','O','N']
    this.acronym = this.matches.join(''); // JSON
    console.log(this.acronym);
    this.studentForm = this.formBuilder.group({
      name: ['', [Validators.required]],
      email: [
        '',
        [
          Validators.required,
          Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$'),
        ],
      ],
      gender: ['', [Validators.required]],
      age: [
        '',
        [
          Validators.required,
          Validators.pattern('^-?[0-9]\\d*(\\.\\d{1,4})?$'),
        ],
      ],
    });
    this.getStudents();
  }

  get f() {
    return this.studentForm.controls;
  }

  getStudents() {
    this.userService.getUsers('user').subscribe(
      (res) => {
        console.log(res);
        this.tableData1 = res;
      },
      (error) => {
        console.error(error);
        this.toastr.error(error, 'Error');
      }
    );
  }

  open(content) {
    this.modalRef = this.modalService.open(content, {
      size: 'lg',
      backdrop: 'static',
    });
  }

  addStudent() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.studentForm.invalid) {
      return;
    }
    this.userService
      .addStudent(
        this.studentForm.value.name,
        this.studentForm.value.email,
        'Admin@123',
        'user',
        this.userData.school,
        this.userData.id,
        this.studentForm.value.age,
        this.studentForm.value.gender
      )
      .subscribe(
        (res) => {
          console.log(res);
          this.toastr.success('Student Added successfully', 'Success!');
          this.studentForm.reset()
          this.getStudents();
        },
        (error) => {
          console.error(error);
          this.toastr.error(error, 'Error');
        }
      );
  }

  deleteStudent(studentId) {
    this.userService.deleteUser(studentId).subscribe(
      (res) => {
        this.toastr.success('Student Deleted successfully', 'Success!');
        this.getStudents();
      },
      (error) => {
        this.toastr.error(error, 'Error');
      }
    );
  }

  generateSurveyLink(studentId: string) {
    this.surveyService.addSurvey(this.userData.school,
      this.userData.id, studentId).subscribe(
        (res) => {
          this.getStudents();
        this.toastr.success('Link Generated successfully', 'Success!');
      },
      (error) => {
        this.toastr.error(error, 'Error');
      }
    );
  }

  copyLink(data) {
    // Create HTML Element
    const selBox = document.createElement('textarea');

    // Set the Styles
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';

    // Set the value
    selBox.value = data[data.length - 1].link;

    // Append the child to the body
    document.body.appendChild(selBox);

    // Append Focus and select
    selBox.focus();
    selBox.select();

    // Execute the command to copy
    document.execCommand('copy');

    // Remove the child once done
    document.body.removeChild(selBox);

    this.toastr.success('Link copied successfully', 'Success!');
  }
}
