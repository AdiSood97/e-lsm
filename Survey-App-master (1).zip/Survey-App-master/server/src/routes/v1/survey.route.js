const express = require('express');
const auth = require('../../middlewares/auth');
const validate = require('../../middlewares/validate');
const surveyValidation = require('../../validations/survey.validation');
const surveyController = require('../../controllers/survey.controller');

const router = express.Router();

router
  .route('/')
  .post(auth('manageSurveys'), validate(surveyValidation.createSurvey), surveyController.createSurvey)
  .get(auth('getSurveys'), validate(surveyValidation.getSurveys), surveyController.getSurveys);

router
  .route('/:surveyId')
  .get(validate(surveyValidation.getSurvey), surveyController.getSurvey)
  .patch(auth('manageSurveys'), validate(surveyValidation.updateSurvey), surveyController.updateSurvey)
  .delete(auth('manageSurveys'), validate(surveyValidation.deleteSurvey), surveyController.deleteSurvey);

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Surveys
 *   description: Survey management and retrieval
 */

/**
 * @swagger
 * path:
 *  /surveys:
 *    post:
 *      summary: Create a Survey
 *      description: Only admin and teacher can create other Surveys.
 *      tags: [Surveys]
 *      security:
 *        - bearerAuth: []
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              required:
 *                - teacher
 *                - school
 *                - student
 *              properties:
 *                teacher:
 *                  type: string
 *                school:
 *                  type: string
 *                student:
 *                  type: string
 *              example:
 *                teacher: 218731hbrgf2y381r
 *                school: 218731hbrgf2y381r
 *                student: 218731hbrgf2y381r
 *      responses:
 *        "201":
 *          description: Created
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Survey'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *
 *    get:
 *      summary: Get all surveys
 *      description: Only admin and teacher can retrieve all surveys.
 *      tags: [Surveys]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: query
 *          name: sortBy
 *          schema:
 *            type: string
 *          description: sort by query in the form of field:desc/asc (ex. name:asc)
 *        - in: query
 *          name: limit
 *          schema:
 *            type: integer
 *            minimum: 1
 *          default: 10
 *          description: Maximum number of surveys
 *        - in: query
 *          name: page
 *          schema:
 *            type: integer
 *            minimum: 1
 *            default: 1
 *          description: Page number
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  results:
 *                    type: array
 *                    items:
 *                      $ref: '#/components/schemas/Survey'
 *                  page:
 *                    type: integer
 *                    example: 1
 *                  limit:
 *                    type: integer
 *                    example: 10
 *                  totalPages:
 *                    type: integer
 *                    example: 1
 *                  totalResults:
 *                    type: integer
 *                    example: 1
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 */

/**
 * @swagger
 * path:
 *  /surveys/{id}:
 *    get:
 *      summary: Get a survey
 *      description: admin, teacher and dtudent can fetch Surveys.
 *      tags: [Surveys]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Survey id
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Survey'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    patch:
 *      summary: Update a survey
 *      description: Only admin and teacher can update surveys.
 *      tags: [Surveys]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Survey id
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              required:
 *                - teacher
 *                - school
 *                - student
 *              properties:
 *                teacher:
 *                  type: string
 *                school:
 *                  type: string
 *                student:
 *                  type: string
 *              example:
 *                teacher: 218731hbrgf2y381r
 *                school: 218731hbrgf2y381r
 *                student: 218731hbrgf2y381r
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Survey'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    delete:
 *      summary: Delete a survey
 *      description: admin and teacher can delete other surveys.
 *      tags: [Surveys]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Survey id
 *      responses:
 *        "200":
 *          description: No content
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 */
