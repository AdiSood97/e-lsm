module.exports.Token = require('./token.model');
module.exports.User = require('./user.model');
module.exports.School = require('./school.model');
module.exports.Survey = require('./survey.model');
