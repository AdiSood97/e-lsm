const Joi = require('@hapi/joi');
const { objectId } = require('./custom.validation');

const createSurvey = {
  body: Joi.object().keys({
    teacher: Joi.string().required(),
    school: Joi.string().required(),
    student: Joi.string().required(),
  }),
};

const getSurveys = {
  query: Joi.object().keys({
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

const getSurvey = {
  params: Joi.object().keys({
    surveyId: Joi.string().custom(objectId),
  }),
};

const updateSurvey = {
  params: Joi.object().keys({
    surveyId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      teacher: Joi.string().required(),
      school: Joi.string().required(),
      student: Joi.string().required()
    })
    .min(1),
};

const deleteSurvey = {
  params: Joi.object().keys({
    surveyId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createSurvey,
  getSurveys,
  getSurvey,
  updateSurvey,
  deleteSurvey,
};
