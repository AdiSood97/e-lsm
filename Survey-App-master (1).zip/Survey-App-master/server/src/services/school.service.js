const httpStatus = require('http-status');
const { School } = require('../models');
const ApiError = require('../utils/ApiError');

/**
 * Create a school
 * @param {Object} schoolBody
 * @returns {Promise<School>}
 */
const createSchool = async (schooBody) => {
  const school = await School.create(schooBody);
  return school;
};

/**
 * Query for school
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const querySchools = async (filter, options) => {
  const schools = await School.paginate(filter, options);
  return schools;
};

/**
 * Get school by id
 * @param {ObjectId} id
 * @returns {Promise<School>}
 */
const getSchoolById = async (id) => {
  return School.findById(id);
};


/**
 * Update school by id
 * @param {ObjectId} schoolId
 * @param {Object} updateBody
 * @returns {Promise<School>}
 */
const updateSchoolById = async (schoolId, updateBody) => {
  const school = await getSchoolById(schoolId);
  if (!school) {
    throw new ApiError(httpStatus.NOT_FOUND, 'School not found');
  }
  Object.assign(school, updateBody);
  await school.save();
  return school;
};

/**
 * Delete school by id
 * @param {ObjectId} schoolId
 * @returns {Promise<School>}
 */
const deleteSchoolById = async (schoolId) => {
  const school = await getSchoolById(schoolId);
  if (!school) {
    throw new ApiError(httpStatus.NOT_FOUND, 'School not found');
  }
  await school.remove();
  return school;
};

module.exports = {
  createSchool,
  querySchools,
  getSchoolById,
  updateSchoolById,
  deleteSchoolById,
};
