import { NgModule } from '@angular/core';
import { CommonModule, } from '@angular/common';
import { BrowserModule  } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './_guards/auth.guard';
import { AdminLayoutComponent } from './_components/layouts/admin-layout/admin-layout.component';

import { PagenotfoundComponent } from './_components/pagenotfound/pagenotfound.component';

import { AuthComponent } from '../app/_components/auth/auth.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'auth/login',
    pathMatch: 'full',
  },
  {
    path: 'auth',
    component: AuthComponent,
    children: [
      {
        path: '',
        loadChildren: './_components/auth/auth.module#AuthModule',
      },
    ],
  },
  {
    path: 'app',
    canActivate: [AuthGuard],
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren:
          './_components/layouts/admin-layout/admin-layout.module#AdminLayoutModule',
      },
    ],
  },
  { path: '**', component: PagenotfoundComponent },
];

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(routes,{
       useHash: true
    })
  ],
  exports: [
  ],
})
export class AppRoutingModule { }
