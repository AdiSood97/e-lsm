import { FormGroup } from '@angular/forms';

// custom validator to check that two fields match
export function validUsername(controlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
        

        if (control.errors && !control.errors.validUsername) {
            // return if another validator has already found an error on the matchingControl
            return;
        }
      
        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        // set error on matchingControl if validation fails
     
      if (!reg.test(control.value)) {
            if (!control.value.match(/^\d{10}/)) {
              control.setErrors({ validUsername: true });
            } else {
              control.setErrors(null);
            }
         
        } else {
         
            control.setErrors(null);
          
        } 
    }
}

// custom validator to check that two fields match
export function invalidEmail(controlName: string) {
  return (formGroup: FormGroup) => {
    const control = formGroup.controls[controlName];
      

      if (control.errors && !control.errors.invalidEmail) {
          // return if another validator has already found an error on the matchingControl
          return;
      }
    
      var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

      // set error on matchingControl if validation fails
   
    if (!reg.test(control.value)) {
    
            control.setErrors({ invalidEmail: true });
          
       
      } else {
       
          control.setErrors(null);
        
      } 
  }
}