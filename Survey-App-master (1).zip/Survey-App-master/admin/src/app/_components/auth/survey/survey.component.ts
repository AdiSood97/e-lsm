import { Component, OnInit } from '@angular/core';
import { UserService, SurveyService } from '../../../_services/index';
import { Router, ActivatedRoute} from '@angular/router';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-survey',
  templateUrl: './survey.component.html',
  styleUrls: ['./survey.component.css']
})
export class SurveyComponent implements OnInit {

  public surveyDetail: any = [];
  constructor(private userService: UserService,
    public router: Router,
    private toastr: ToastrService,
    private surveyService: SurveyService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.getStudentInfo(this.route.snapshot.paramMap.get("surveyId"))
  }

  getStudentInfo(surveytId: String) {
    this.surveyService.getSurveyById(surveytId).subscribe(
      (res) => {
          this.surveyDetail = res;
          this.toastr.success('Data fetched successfully', 'Success!');
        },
        (error) => {
          this.toastr.error(error, 'Error');
        }
      );
  }
}
