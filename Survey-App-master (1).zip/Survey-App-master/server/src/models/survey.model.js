const mongoose = require('mongoose');
const { toJSON, paginate } = require('./plugins');
const { status } = require('../config/status');
const config = require('../config/config');

const surveySchema = mongoose.Schema(
  {
    teacher: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'User',
    },
    student: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'User',
    },
    school: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: 'School',
    },
    link: {
      type: String,
      default: '',
    },
    status: {
      type: String,
      enum: status,
      default: 'pending',
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
surveySchema.plugin(toJSON);
surveySchema.plugin(paginate);

surveySchema.post('save', async function (doc) {
  const survey = doc;
  survey.link = `${config.appURL}auth/survey/${survey.id}`;
  survey.save();
});

/**
 * @typedef Survey
 */
const Survey = mongoose.model('Survey', surveySchema);

module.exports = Survey;
