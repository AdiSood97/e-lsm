import { Component, OnInit } from '@angular/core';

declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
}
export const ROUTES: RouteInfo[] = [
  {
    path: '/app/dashboard',
    title: 'Dashboard',
    icon: 'pe-7s-graph',
    class: '',
  },
  {
    path: '/app/student-list',
    title: 'Student List',
    icon: 'pe-7s-user',
    class: '',
  }
];

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html'
})
export class SidebarComponent implements OnInit {
  menuItems: any = [];
  userData: any = [];
  matches: any;
  acronym: any;
  username: any;
  constructor() { }

  ngOnInit() {
    this.userData = JSON.parse(localStorage.getItem('user'));
    this.matches = this.userData.name.match(/\b(\w)/g);
    this.acronym = this.matches.join('');
    console.log(this.username);
    this.menuItems = ROUTES.filter(menuItem => menuItem);
    if (this.userData['role'] === 'admin') {
      this.menuItems.push(
        {
          path: '/app/school-list',
          title: 'School List',
          icon: 'pe-7s-study',
          class: '',
        },
        {
          path: '/app/teacher-list',
          title: 'Teacher List',
          icon: 'pe-7s-notebook',
          class: '',
        }
      );
    }
  }
  isMobileMenu() {
      if ($(window).width() > 991) {
          return false;
      }
      return true;
  };
}
