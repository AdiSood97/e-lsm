import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  HttpClientModule,
  HTTP_INTERCEPTORS,
} from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { ToastrModule } from 'ngx-toastr';

// all guards
import { AuthGuard } from './_guards/auth.guard';
// all intercepters
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
// all services
import { AuthenticationService, SchoolService, UserService, SurveyService} from './_services/index';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app.routing';
import { NavbarModule } from '../app/_components/shared/navbar/navbar.module';
import { FooterModule } from '../app/_components/shared/footer/footer.module';
import { SidebarModule } from '../app/_components/sidebar/sidebar.module';

import { AppComponent } from '../app/_components/app.component';
import { PagenotfoundComponent } from '../app/_components/pagenotfound/pagenotfound.component';
import { AdminLayoutComponent } from '../app/_components/layouts/admin-layout/admin-layout.component';
import { AuthComponent } from '../app/_components/auth/auth.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';


@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    RouterModule,
    HttpClientModule,
    NavbarModule,
    FooterModule,
    SidebarModule,
    AppRoutingModule,
    ToastrModule.forRoot({
      timeOut: 10000,
      positionClass: 'toast-top-right',
      preventDuplicates: true,
    }), // ToastrModule added
    NgbModule, ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
  ],
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    PagenotfoundComponent,
    AuthComponent,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    AuthGuard,
    AuthenticationService,
    SchoolService,
    UserService,
    SurveyService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
